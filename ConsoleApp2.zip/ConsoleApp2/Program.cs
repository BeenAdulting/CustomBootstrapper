﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Xml.Linq;
using Newtonsoft.Json.Linq;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "BootstrapperV2 By Adulting";

            Console.ForegroundColor = (ConsoleColor)13;
            Console.WriteLine("    ____              __  _____ __                                  _    _____ \r\n   / __ )____  ____  / /_/ ___// /__________ _____  ____  ___  ____| |  / /__ \\\r\n  / __  / __ \\/ __ \\/ __/\\__ \\/ __/ ___/ __ `/ __ \\/ __ \\/ _ \\/ ___/ | / /__/ /\r\n / /_/ / /_/ / /_/ / /_ ___/ / /_/ /  / /_/ / /_/ / /_/ /  __/ /   | |/ // __/ \r\n/_____/\\____/\\____/\\__//____/\\__/_/   \\__,_/ .___/ .___/\\___/_/    |___//____/ \r\n                                          /_/   /_/                            ");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Developer & Owner: Adulting. (on discord)");
            Thread.Sleep(1000);
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine(" ");

            Console.ForegroundColor = (ConsoleColor)13;

            Console.WriteLine("Choose an option:");
            Console.WriteLine("Option 1: Fix Roblox 403 Error");
            Console.WriteLine("Option 2: Run Custom Solara Bootstrapper");
            Console.WriteLine("Option 3: Check Roblox Client Version");
            Console.WriteLine("");
            Console.Write("Option: ");
            string choice = Console.ReadLine();
            Console.WriteLine("");

            if (choice == "1")
            {
                FixRoblox403Error();
            }
            else if (choice == "2")
            {
                RunSolaraBootstrapper();
            }
            else if (choice == "3")
            {
                CheckRobloxClientVersion();
            }
            else
            {
                Console.WriteLine("Invalid choice.");
            }
        }

        static void FixRoblox403Error()
        {
            if (IsRobloxRunning())
            {
                Console.WriteLine("");
                Console.WriteLine("Please close Roblox and retry.");
                return;
            }

            string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Roblox");

            if (Directory.Exists(folderPath))
            {
                Console.WriteLine("Deleting Roblox folder...");
                Console.WriteLine("");
                Directory.Delete(folderPath, true);
                Console.WriteLine("Roblox folder deleted successfully.");
            }
            else
            {
                Console.WriteLine("");
                Console.WriteLine("Roblox folder not found in %LOCALAPPDATA%.");
            }

            Thread.Sleep(2000);

            Console.WriteLine("Downloading Roblox installer...");
            Console.WriteLine("");
            string installerURL = "https://setup.rbxcdn.com/version-1088f3c8e4a44cc7-RobloxPlayerInstaller.exe";
            string installerPath = Path.Combine(Path.GetTempPath(), "RobloxPlayerInstaller.exe");
            Console.WriteLine("");

            using (WebClient webClient = new WebClient())
            {
                try
                {
                    webClient.DownloadFile(installerURL, installerPath);
                    Console.WriteLine("Installing Roblox...");
                    Console.WriteLine("");
                    Process.Start(installerPath);
                    Console.WriteLine("Roblox installation started.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Failed to download Roblox installer: " + ex.Message);
                    Console.WriteLine("");
                }
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        static void RunSolaraBootstrapper()
        {
            string url = "https://github.com/BeenAdulting/CustomBootstrapper/raw/main/Solara.zip";
            string downloadsDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            string zipFilePath = Path.Combine(downloadsDir, "Solara.zip");
            string extractPath = Path.Combine(downloadsDir, "Solara");

            if (Directory.Exists(extractPath))
            {
                Console.Clear();
                Console.WriteLine("     ____              __  _____ __                                  _    _____ \r\n   / __ )____  ____  / /_/ ___// /__________ _____  ____  ___  ____| |  / /__ \\\r\n  / __  / __ \\/ __ \\/ __/\\__ \\/ __/ ___/ __ `/ __ \\/ __ \\/ _ \\/ ___/ | / /__/ /\r\n / /_/ / /_/ / /_/ / /_ ___/ / /_/ /  / /_/ / /_/ / /_/ /  __/ /   | |/ // __/ \r\n/_____/\\____/\\____/\\__//____/\\__/_/   \\__,_/ .___/ .___/\\___/_/    |___//____/ \r\n                                          /_/   /_/                            ");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("[Solara Bootstrapper]: Solara already installed.");
                Console.WriteLine("");
                Console.WriteLine("[Solara Bootstrapper]: Opening Solara in 5 seconds...");
                Thread.Sleep(5000);
            }
            else
            {
                using (WebClient client = new WebClient())
                {
                    client.DownloadFile(url, zipFilePath);
                }

                if (File.Exists(zipFilePath))
                {
                    ZipFile.ExtractToDirectory(zipFilePath, extractPath);

                    string nestedDir = Directory.GetDirectories(extractPath)[0];
                    string exePath = Path.Combine(nestedDir, "SolaraBootstrapper.exe");

                    if (File.Exists(exePath))
                    {
                        Console.Clear();
                        Console.WriteLine("    ____              __  _____ __                                  _    _____ \r\n   / __ )____  ____  / /_/ ___// /__________ _____  ____  ___  ____| |  / /__ \\\r\n  / __  / __ \\/ __ \\/ __/\\__ \\/ __/ ___/ __ `/ __ \\/ __ \\/ _ \\/ ___/ | / /__/ /\r\n / /_/ / /_/ / /_/ / /_ ___/ / /_/ /  / /_/ / /_/ / /_/ /  __/ /   | |/ // __/ \r\n/_____/\\____/\\____/\\__//____/\\__/_/   \\__,_/ .___/ .___/\\___/_/    |___//____/ \r\n                                          /_/   /_/                            ");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("[Solara Bootstrapper]: Installing Solara.");
                        Console.WriteLine("");
                        Thread.Sleep(4000);
                        Console.WriteLine("[Solara Bootstrapper]: Solara successfully installed.");
                        Thread.Sleep(2000);
                        Console.Clear();
                        Console.WriteLine("    ____              __  _____ __                                  _    _____ \r\n   / __ )____  ____  / /_/ ___// /__________ _____  ____  ___  ____| |  / /__ \\\r\n  / __  / __ \\/ __ \\/ __/\\__ \\/ __/ ___/ __ `/ __ \\/ __ \\/ _ \\/ ___/ | / /__/ /\r\n / /_/ / /_/ / /_/ / /_ ___/ / /_/ /  / /_/ / /_/ / /_/ /  __/ /   | |/ // __/ \r\n/_____/\\____/\\____/\\__//____/\\__/_/   \\__,_/ .___/ .___/\\___/_/    |___//____/ \r\n                                          /_/   /_/                            ");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("[Solara Bootstrapper]: Opening Solara in 5 seconds...");
                        Thread.Sleep(5000);
                    }
                }
            }

            string nestedDir2 = Directory.GetDirectories(extractPath)[0];
            string exePath2 = Path.Combine(nestedDir2, "SolaraBootstrapper.exe");
            if (File.Exists(exePath2))
            {
                Process.Start(exePath2);
            }
            Console.WriteLine("");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        static void CheckRobloxClientVersion()
        {
            string url = "https://clientsettingscdn.roblox.com/v2/client-version/WindowsPlayer";

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = client.GetAsync(url).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        string responseBody = response.Content.ReadAsStringAsync().Result;

                        // Parse JSON response
                        JObject json = JObject.Parse(responseBody);

                        // Find and print clientVersionUpload
                        string clientVersionUpload = json["clientVersionUpload"].ToString();
                        Console.WriteLine("Roblox Client Version: " + clientVersionUpload);
                        Console.WriteLine("");
                    }
                    else
                    {
                        Console.WriteLine("Failed to retrieve Roblox client version. Status code: " + response.StatusCode);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }

        static bool IsRobloxRunning()
        {
            Process[] processes = Process.GetProcessesByName("RobloxPlayerBeta");
            return processes.Length > 0;
        }
    }
}
