﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Threading;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Solara Custom Bootstrapper By Adulting"; // Set console window title

            Console.ForegroundColor = (ConsoleColor)13;
            Console.WriteLine("███╗   ██╗██╗ ██████╗  ██████╗  █████╗     ██████╗ ██╗ ██████╗██╗  ██╗    ██████╗ ██╗   ██╗████████╗████████╗\r\n████╗  ██║██║██╔════╝ ██╔════╝ ██╔══██╗    ██╔══██╗██║██╔════╝██║ ██╔╝    ██╔══██╗██║   ██║╚══██╔══╝╚══██╔══╝\r\n██╔██╗ ██║██║██║  ███╗██║  ███╗███████║    ██║  ██║██║██║     █████╔╝     ██████╔╝██║   ██║   ██║      ██║   \r\n██║╚██╗██║██║██║   ██║██║   ██║██╔══██║    ██║  ██║██║██║     ██╔═██╗     ██╔══██╗██║   ██║   ██║      ██║   \r\n██║ ╚████║██║╚██████╔╝╚██████╔╝██║  ██║    ██████╔╝██║╚██████╗██║  ██╗    ██████╔╝╚██████╔╝   ██║      ██║   \r\n╚═╝  ╚═══╝╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝    ╚═════╝ ╚═╝ ╚═════╝╚═╝  ╚═╝    ╚═════╝  ╚═════╝    ╚═╝      ╚═╝   \r\n                                                                                                             ");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Developer & Owner: Adulting. (on discord)");
            Thread.Sleep(1000);
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine(" ");

            Console.ForegroundColor = (ConsoleColor)13;

            string url = "https://github.com/BeenAdulting/CustomBootstrapper/raw/main/Solara.zip";
            string downloadsDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            string zipFilePath = Path.Combine(downloadsDir, "Solara.zip");

            string extractPath = Path.Combine(downloadsDir, "Solara");

            if (Directory.Exists(extractPath))
            {
                Console.Clear();
                Console.WriteLine("███╗   ██╗██╗ ██████╗  ██████╗  █████╗     ██████╗ ██╗ ██████╗██╗  ██╗    ██████╗ ██╗   ██╗████████╗████████╗\r\n████╗  ██║██║██╔════╝ ██╔════╝ ██╔══██╗    ██╔══██╗██║██╔════╝██║ ██╔╝    ██╔══██╗██║   ██║╚══██╔══╝╚══██╔══╝\r\n██╔██╗ ██║██║██║  ███╗██║  ███╗███████║    ██║  ██║██║██║     █████╔╝     ██████╔╝██║   ██║   ██║      ██║   \r\n██║╚██╗██║██║██║   ██║██║   ██║██╔══██║    ██║  ██║██║██║     ██╔═██╗     ██╔══██╗██║   ██║   ██║      ██║   \r\n██║ ╚████║██║╚██████╔╝╚██████╔╝██║  ██║    ██████╔╝██║╚██████╗██║  ██╗    ██████╔╝╚██████╔╝   ██║      ██║   \r\n╚═╝  ╚═══╝╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝    ╚═════╝  ╚═╝ ╚═════╝╚═╝  ╚═╝    ╚═════╝  ╚═════╝    ╚═╝      ╚═╝   \r\n                                                                                                             ");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("[Solara Bootstrapper]: Solara already installed.");
                Console.WriteLine("[Solara Bootstrapper]: Opening Solara in 5 seconds...");
                Thread.Sleep(5000);
            }
            else
            {
                using (WebClient client = new WebClient())
                {
                    client.DownloadFile(url, zipFilePath);
                }

                if (File.Exists(zipFilePath))
                {
                    ZipFile.ExtractToDirectory(zipFilePath, extractPath);

                    // Navigate through nested folder
                    string nestedDir = Directory.GetDirectories(extractPath)[0];
                    string exePath = Path.Combine(nestedDir, "SolaraBootstrapper.exe");

                    if (File.Exists(exePath))
                    {
                        Console.Clear();
                        Console.WriteLine("███╗   ██╗██╗ ██████╗  ██████╗  █████╗     ██████╗ ██╗ ██████╗██╗  ██╗    ██████╗ ██╗   ██╗████████╗████████╗\r\n████╗  ██║██║██╔════╝ ██╔════╝ ██╔══██╗    ██╔══██╗██║██╔════╝██║ ██╔╝    ██╔══██╗██║   ██║╚══██╔══╝╚══██╔══╝\r\n██╔██╗ ██║██║██║  ███╗██║  ███╗███████║    ██║  ██║██║██║     █████╔╝     ██████╔╝██║   ██║   ██║      ██║   \r\n██║╚██╗██║██║██║   ██║██║   ██║██╔══██║    ██║  ██║██║██║     ██╔═██╗     ██╔══██╗██║   ██║   ██║      ██║   \r\n██║ ╚████║██║╚██████╔╝╚██████╔╝██║  ██║    ██████╔╝██║╚██████╗██║  ██╗    ██████╔╝╚██████╔╝   ██║      ██║   \r\n╚═╝  ╚═══╝╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝    ╚═════╝  ╚═╝ ╚═════╝╚═╝  ╚═╝    ╚═════╝  ╚═════╝    ╚═╝      ╚═╝   \r\n                                                                                                             ");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("[Solara Bootstrapper]: Installing Solara.");
                        Console.WriteLine("");
                        Thread.Sleep(4000);
                        Console.WriteLine("[Solara Bootstrapper]: Solara successfully installed.");
                        Thread.Sleep(2000);
                        Console.Clear();
                        Console.WriteLine("███╗   ██╗██╗ ██████╗  ██████╗  █████╗     ██████╗ ██╗ ██████╗██╗  ██╗    ██████╗ ██╗   ██╗████████╗████████╗\r\n████╗  ██║██║██╔════╝ ██╔════╝ ██╔══██╗    ██╔══██╗██║██╔════╝██║ ██╔╝    ██╔══██╗██║   ██║╚══██╔══╝╚══██╔══╝\r\n██╔██╗ ██║██║██║  ███╗██║  ███╗███████║    ██║  ██║██║██║     █████╔╝     ██████╔╝██║   ██║   ██║      ██║   \r\n██║╚██╗██║██║██║   ██║██║   ██║██╔══██║    ██║  ██║██║██║     ██╔═██╗     ██╔══██╗██║   ██║   ██║      ██║   \r\n██║ ╚████║██║╚██████╔╝╚██████╔╝██║  ██║    ██████╔╝██║╚██████╗██║  ██╗    ██████╔╝╚██████╔╝   ██║      ██║   \r\n╚═╝  ╚═══╝╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝    ╚═════╝  ╚═╝ ╚═════╝╚═╝  ╚═╝    ╚═════╝  ╚═════╝    ╚═╝      ╚═╝   \r\n                                                                                                             ");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("[Solara Bootstrapper]: Opening Solara in 5 seconds...");
                        Thread.Sleep(5000);
                    }
                }
            }

            string nestedDir2 = Directory.GetDirectories(extractPath)[0];
            string exePath2 = Path.Combine(nestedDir2, "SolaraBootstrapper.exe");
            if (File.Exists(exePath2))
            {
                Process.Start(exePath2);
            }
        }
    }
}